#include <stdio.h>

main() {
sleep(3600);
}
